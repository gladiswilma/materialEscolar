import { Component } from '@angular/core';

@Component({
  selector: 'app-quem-somos',
  standalone: true,
  imports: [],
  templateUrl: './quem-somos.component.html',
  styleUrl: './quem-somos.component.scss'
})
export class QuemSomosComponent {

}
